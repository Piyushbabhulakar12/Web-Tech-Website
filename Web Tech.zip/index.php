<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">

    <!-- Font CSS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">


    <title>Web Tech Company</title>
    <style type="text/css">
      html {
  scroll-behavior: smooth;
}
      body
      {
        font-family: 'Poppins', sans-serif;
        background-color: #fff;
        font-weight: 600;
      }
      .link_text
      {
        padding-left: 5px;
        color: #cccccc;
        font-weight: 500;
      }
      .link_text:hover
      {
        color:#1D77FE;
      }
    </style>
  </head>
  <body>
   




    <div class="container-fluid">
      <div class="row">
        <div class="d-none d-xl-block d-lg-block d-md-block col-md-1">
          
         <div class="sticky-top">

           <h6 class="mt-3 text-center" style="font-weight: 600;">Web Tech Company</h6>
           
<nav class="nav flex-column mt-3">
  <a class="nav-link link_text active" aria-current="page" href="index.php">Home</a>
  <a class="nav-link link_text" href="#service">Service</a>
  <a class="nav-link link_text" href="#about">About</a>
  <a class="nav-link link_text" href="#cases">Cases</a>
  <a class="nav-link link_text" href="#workflow">Workflow</a>
  <a class="nav-link link_text" href="#team">Team</a>
  <a class="nav-link link_text" href="#services">Technology</a>
  <a class="nav-link link_text" href="#contact">Contact Us</a>
</nav>
           
         </div>

        </div>
        <div class="col-md-11 col-12">
         

         <div class="container-fluid">
           <div class="row">
             <div class="col-12">
               <h6 class="text-end mt-3" style="font-size: 15px; font-weight: 600; text-decoration: underline;">webtechcomp@gmail.com</h6>
             </div>
           </div>
         </div>


         <div class="container">
           <div class="row">
             <div class="col-md-7">
               
               <div style="margin-top:90px;">
                 <h6 style="font-size: 15px; color: #1D77FE; font-weight: 600;">What We Offer</h6>
                 <h1 style="line-height: 1.2; font-weight: 500; font-size: 55px;">Web Tech Company <br> Your Trade Vision</h1>
                 <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-3">It has survived not only five centuries, but also the leap into electronic
typesetting, remaining essentially unchanged. It was popularised in the
1960s with the release of Letraset sheets containing Lorem Ipsum
passages, and more recently with desktop publishing software like Aldus
PageMaker including versions of Lorem Ipsum.</p>

              <button class="btn btn-primary rounded-pill p-3 mt-3" style="width: 250px;">Discuss my project</button> &nbsp;&nbsp;
              <button class="btn rounded-pill p-3 mt-3" style="width: 200px; border:1px solid #C7C6C6; font-weight: 600;">Explore</button>


               </div>


             </div>
             <div class="col-md-5 d-none d-none d-xl-block d-lg-block d-md-block" style="background-image: url('Image/Pic1.png'); height: 550px; background-repeat: no-repeat; background-position: center;">
               
             </div>
           </div>
         </div>


        
        <div class="container">
          <div class="row">
            <div class="col-md-3">
               <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-3">Develop e-commerce <br> software solution</p>
            </div>
             <div class="col-md-3">
               <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-3">Audit and technical support <br> for existing solution</p>
            </div>
             <div class="col-md-3">
               <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-3">Manual ans automatic<br>quality control</p>
            </div>
             <div class="col-md-3">
              
            </div>
          </div>
        </div>
       

       <hr>



       <div class="container">
         <div class="row">
           <div class="col-md-12">
            <a id="service"></a>
             <div style="margin-top: 50px;">

               <h6 style="font-size: 15px; color: #1D77FE; font-weight: 600;">Services</h6>
               <h2 style="font-weight: 600;">What We Do?</h2>
             </div>
           </div>
         </div>
       </div>


       <div class="container" style="margin-top: 40px;">
          <div class="card p-3">
            <div class="container-fluid">
              <div class="row">
                <div class="col-md-1">
                  <p style="font-size: 24px; margin-top: 100px; font-weight: 500; color: #9E9E9E;">01</p>
                </div>
                <div class="col-md-5" style="height: 210px; background-image: url('Image/Pic2.png'); background-repeat: no-repeat; background-position: center;">
                  
                </div>
                <div class="col-md-6">
                  
                  <div style="margin-top: 30px;">
                    <h2 style="font-weight: 600;">Lorem Ipsum is not simply</h2>
                  <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-3">It has survived not only five centuries, but also the leap into electronic
typesetting, remaining essentially unchanged. It was popularised in the
1960s with the release of Letraset sheets containing Lorem Ipsum
passages, and more recently with desktop publishing software like Aldus
PageMaker including versions of Lorem Ipsum.</p>
                  </div>

                </div>
              </div>
            </div>
          </div>
       </div>


       <div class="container" style="margin-top: 40px;">
          <div class="card p-3">
            <div class="container-fluid">
              <div class="row">
                <div class="col-md-1">
                  <p style="font-size: 24px; margin-top: 100px; font-weight: 500; color: #9E9E9E;">02</p>
                </div>
                <div class="col-md-5" style="height: 210px; background-image: url('Image/Pic3.png'); background-repeat: no-repeat; background-position: center;">
                  
                </div>
                <div class="col-md-6">
                  
                  <div style="margin-top: 30px;">
                    <h2 style="font-weight: 600;">Lorem Ipsum is not simply</h2>
                  <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-3">It has survived not only five centuries, but also the leap into electronic
typesetting, remaining essentially unchanged. It was popularised in the
1960s with the release of Letraset sheets containing Lorem Ipsum
passages, and more recently with desktop publishing software like Aldus
PageMaker including versions of Lorem Ipsum.</p>
                  </div>

                </div>
              </div>
            </div>
          </div>
       </div>

       <div class="container" style="margin-top: 40px;">
          <div class="card p-3">
            <div class="container-fluid">
              <div class="row">
                <div class="col-md-1">
                  <p style="font-size: 24px; margin-top: 100px; font-weight: 500; color: #9E9E9E;">03</p>
                </div>
                <div class="col-md-5" style="height: 210px; background-image: url('Image/Pic4.png'); background-repeat: no-repeat; background-position: center;">
                  
                </div>
                <div class="col-md-6">
                  
                  <div style="margin-top: 30px;">
                    <h2 style="font-weight: 600;">Lorem Ipsum is not simply</h2>
                  <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-3">It has survived not only five centuries, but also the leap into electronic
typesetting, remaining essentially unchanged. It was popularised in the
1960s with the release of Letraset sheets containing Lorem Ipsum
passages, and more recently with desktop publishing software like Aldus
PageMaker including versions of Lorem Ipsum.</p>
                  </div>

                </div>
              </div>
            </div>
          </div>
       </div>
       


         <div style="background-color: #f4f4f4; height: auto; margin-top: 100px; padding-bottom: 80px;">


   
          <div class="container">
            <div class="row">
              <a id="about"></a>
              <div class="col-md-6"  style="margin-top: 80px;">
                
                <div>
               <h6 style="font-size: 15px; color: #1D77FE; font-weight: 600;">About Us</h6>
               <h2 style="font-weight: 600;">Lorem ipsum</h2>
             </div>

              </div>
              <div class="col-md-6" style="margin-top: 80px;">

                    <p style="font-weight: 600; font-size: 14px;">But I must explain to you</p>
                    <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

                    <hr class="mt-2">

                     <p style="font-weight: 600; font-size: 14px;">But I must explain to you</p>
                    <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

                    <hr class="mt-2">

                     <p style="font-weight: 600; font-size: 14px;">But I must explain to you</p>
                    <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

                    <hr class="mt-2">

 
                
              </div>
            </div>
          </div>



         </div>






         <div class="container">
         <div class="row">
          <a id="cases"></a>
           <div class="col-md-12">
             <div style="margin-top: 90px;">
               <h6 style="font-size: 15px; color: #1D77FE; font-weight: 600;">Cases</h6>
               <h2 style="font-weight: 600;">We Have Solutions For Business <br> Inquiries or issue</h2>
             </div>
           </div>
         </div>
       </div>


       <div class="container" style="margin-top: 40px;">
         <div class="row">
           <div class="col-6">
             <h3 style="font-weight: 500;">Project</h3>
           </div>
           <div class="col-6">
            <div class="float-end">
               <button class="btn border" style="height: 45px; width: 45px; border-radius: 50px;" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev"><i class="bi bi-chevron-left"></i></button>&nbsp;
             <button class="btn border" style="height: 45px; width: 45px; border-radius: 50px;" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next"><i class="bi bi-chevron-right"></i></button>
            </div>
           </div>
         </div>
       </div>


       <div class="container" style="margin-top: 30px;">
         <div class="row">
           <div class="col-12">
             
             <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="">
        <div class="row">
          <div class="col-md-4">
            <img src="https://piyushbabhulakar12.github.io/piyushbabhulakar/img4.png" style="height: 210px; width: 100%; object-fit: cover;">
          </div>
          <div class="col-md-8">
           
           <p style="font-weight: 600; font-size: 14px;">But I must explain to you</p>
                    <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

<p style="font-weight: 600; font-size: 14px;">But I must explain to you</p>
                    <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

          </div>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <div class="">
        <div class="row">
          <div class="col-md-4">
            <img src="https://piyushbabhulakar12.github.io/piyushbabhulakar/img3.png" style="height: 210px; width: 100%; object-fit: cover;">
          </div>
          <div class="col-md-8">
           
           <p style="font-weight: 600; font-size: 14px;">But I must explain to you</p>
                    <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

<p style="font-weight: 600; font-size: 14px;">But I must explain to you</p>
                    <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

          </div>
        </div>
      </div>
    </div>
    <div class="carousel-item">
      <div class="">
        <div class="row">
          <div class="col-md-4">
            <img src="https://piyushbabhulakar12.github.io/piyushbabhulakar/img1.png" style="height: 210px; width: 100%; object-fit: cover;">
          </div>
          <div class="col-md-8">
           
           <p style="font-weight: 600; font-size: 14px;">But I must explain to you</p>
                    <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

<p style="font-weight: 600; font-size: 14px;">But I must explain to you</p>
                    <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

           </div>
         </div>
       </div>



       
       <div class="container" style="margin-top: 60px;">
         <div class="row">
           <div class="col-md-8">
             <div style="background-color: #f4f4f4; padding: 15px;">
              
               <p style="font-weight: 600; font-size: 14px;" class="mt-3">But I must explain to you</p>
                    <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

 <p style="font-weight: 600; font-size: 14px;">But I must explain to you</p>
                    <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

             </div>
           </div>
           <div class="col-md-4">
            <div style="background-color: #333437; padding: 15px;">

                <h2 style="font-weight: 600; color: #fff;">Let s make something great together</h2>
                <button class="btn rounded-pill p-3" style="margin-top: 65px; width: 200px; border:1px solid #C7C6C6; color:#fff; font-weight: 600;">Explore</button>
               
             </div>
           </div>
         </div>
       </div>



<div class="container">
         <div class="row">
          <a id="workflow"></a>
           <div class="col-md-12">
             <div style="margin-top: 90px;">
               <h6 style="font-size: 15px; color: #1D77FE; font-weight: 600;">Workflow</h6>
               <h2 style="font-weight: 600;">How we do it ?</h2>
             </div>
           </div>
         </div>
       </div>



        
        <div class="container">
          <div class="row">
            <div class="col-md-5">
               

               <img src="Image/proccess1.png" style="height: 220px; width: 100%; object-fit: contain;"><br>
               <img src="Image/proccess2.png" style="height: 220px; width: 100%; object-fit: contain;"><br>
               <img src="Image/proccess3.png" style="height: 220px; width: 100%; object-fit: contain;">




            </div>
            <div class="col-md-2">
             

             <div style="margin-top: 120px;" class="d-none d-xl-block d-lg-block d-md-block">
                <center><button class="btn border" style="height: 50px; width: 50px; border-radius: 50px;">01</button></center>

              <div class="progress" style=" transform: rotate(-90deg); margin-top: 80px; height: 0.4px;">
  <div class="progress-bar bg-dark" role="progressbar" style="width: 100%" aria-valuenow="150" aria-valuemin="0" aria-valuemax="150" style="width: 25%;"></div>
</div>

<center><button class="btn border" style="height: 50px; width: 50px; border-radius: 50px; margin-top: 80px;">02</button></center>

              <div class="progress" style=" transform: rotate(-90deg); margin-top: 80px; height: 0.4px;">
  <div class="progress-bar bg-dark" role="progressbar" style="width: 100%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="50" style="width: 25%;"></div>
</div>
<center><button class="btn border" style="height: 50px; width: 50px; border-radius: 50px; margin-top: 80px;">03</button></center>

             </div>
          


            </div>
            <div class="col-md-5">
             
 
              <h3 style="font-weight: 600; margin-top: 20px;">We Have Solutions</h3>
              <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

 <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">It is a long established fact that a reader will be
distracted by the readable content of a page when
looking at its layout. </p>

 <h3 style="font-weight: 600; margin-top: 40px;">We Have Solutions</h3>
              <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

 <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">It is a long established fact that a reader will be
distracted by the readable content of a page when
looking at its layout. </p>

 <h3 style="font-weight: 600; margin-top: 40px;">We Have Solutions</h3>
              <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">Sed ut perspiciatis unde omnis iste natus error sit voluptatem
accusantium doloremque laudantium, totam rem aperiam,
eaque ipsa quae ab illo inventore veritatis et quasi architecto
beatae vitae dicta sunt explicabo. Nemo enim ipsam
voluptatem quia voluptas </p>

 <p style="font-size: 14px; font-weight: 500; color: #9E9E9E;" class="mt-2">It is a long established fact that a reader will be
distracted by the readable content of a page when
looking at its layout. </p>





            </div>
          </div>
        </div>





<div style="background-color: #f4f4f4; height: auto; margin-top: 100px; padding-bottom: 80px;">

  <div class="container">
         <div class="row">
           <a id="team"></a>
           <div class="col-md-12">
             <div style="margin-top: 90px;">
               <h6 style="font-size: 15px; color: #1D77FE; font-weight: 600;">Our Team</h6>
               <h2 style="font-weight: 600;">Your Developer Team</h2>
             </div>
           </div>
         </div>
       </div>
  




<div class="container mt-5">
  <div class="row">
    <div class="col-md-4">
      <img src="Image/team1.png" style="height: 160px; width: 100%; object-fit: contain;" title="Hello I'm Nick and I Build Thing For The Web">
    </div>
    <div class="col-md-4">
       <img src="Image/team2.png" style="height: 160px; width: 100%; object-fit: contain;" title="Hello I'm Jon and I Build Thing For The Web">
    </div>
    <div class="col-md-4">
       <img src="Image/team3.png" style="height: 160px; width: 100%; object-fit: contain;" title="Hello I'm Lila and I Build Thing For The Web">
    </div>
    <div class="col-md-4 mt-5">
      <img src="Image/team4.png" style="height: 160px; width: 100%; object-fit: contain;" title="Hello I'm Arohi and I Build Thing For The Web"
      >
    </div>
    <div class="col-md-4 mt-5">
       <img src="Image/team5.png" style="height: 160px; width: 100%; object-fit: contain;" title="Hello I'm Jessi and I Build Thing For The Web">
    </div>
    <div class="col-md-4 mt-5">
       <img src="Image/team6.png" style="height: 160px; width: 100%; object-fit: contain;" title="Hello I'm Kegg and I Build Thing For The Web">
    </div>
  </div>
</div>

</div>



<div class="container">
         <div class="row">
          <a id="services"></a>
           <div class="col-md-12">
             <div style="margin-top: 90px;">
               <h6 style="font-size: 15px; color: #1D77FE; font-weight: 600;">Services</h6>
               <h2 style="font-weight: 600;">Technology in Action</h2>
             </div>
           </div>
         </div>
</div>


<div class="container mt-5">
  <iframe src="slider.html" style="height: 160px; width: 100%;"></iframe>
</div>





<div class="container">
         <div class="row">
           <a id="contact"></a>
           <div class="col-md-12">
             <div style="margin-top: 90px;">
               <h6 style="font-size: 15px; color: #1D77FE; font-weight: 600;">Contact Us</h6>
               <h2 style="font-weight: 600;">Tell Us About Ideas <br> We ll Do The Rest</h2>
             </div>
           </div>
         </div>
</div>




<div class="container mt-5">
  <div class="row">
    <div class="col-md-5">
      <h5 style="font-weight: 600;"><span style="color:#cccccc;">01</span>&nbsp;Pick Up Project</h5>


    <div class="row mt-5">
      <div class="col-md-6">
        <div class="card p-5">
          
          <center>
            <i class="bi bi-card-heading" style="font-size: 30px; color: #cccccc;"></i><br><br>
            <h6 style="font-weight: 600;">AD'S</h6>
          </center>

        </div>
      </div>
      <div class="col-md-6">
        <div class="card p-5">
          
           <center>
            <i class="bi bi-search" style="font-size: 30px; color: #cccccc;"></i><br><br>
            <h6 style="font-weight: 600;">SEO</h6>
          </center>

        </div>
      </div>
    </div>

    <div class="row mt-4">
      <div class="col-md-6">
        <div class="card p-5">
          
          <center>
            <i class="bi bi-card-heading" style="font-size: 30px; color: #cccccc;"></i><br><br>
            <h6 style="font-weight: 600;">SocialMedia Marketing</h6>
          </center>

        </div>
      </div>
      <div class="col-md-6">
        <div class="card p-5">
          
           <center>
            <i class="bi bi-tv" style="font-size: 30px; color: #cccccc;"></i><br><br>
            <h6 style="font-weight: 600;">Web - site Designing</h6>
          </center>

        </div>
      </div>
    </div>



    </div>
    <div class="col-1">
      
    </div>
     <div class="col-md-6">
      <h5 style="font-weight: 600;"><span style="color:#cccccc;">02</span>&nbsp;Wright more about it</h5>

          <form method="post" class="mt-5">
            <input type="text" name="name" placeholder="Full Name" class="form-control mt-4"> 
            <input type="text" name="email" placeholder="Email Id" class="form-control mt-3"> 
            <textarea name="message" placeholder="Message" class="form-control mt-3" rows="5"></textarea>
            <button class="btn btn-primary rounded-pill mt-3 p-2" type="submit" name="submit" style="width: 190px;">Send Message <i class="bi bi-arrow-right"></i></button>
          </form>


    </div>
  </div>
</div>



<?php

$conn = mysqli_connect("localhost","root","","user");

if (isset($_POST['submit'])) 
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];
    $date = date("Y/m/d");

    $sql = " insert into user_detail (name,email,message,date) values ('$name','$email','$message','$date') ";

    if (mysqli_query($conn,$sql)) 
    {
     
    }
    else
    {
      echo "Not Done";
    }

}

?>







         
        </div>
      </div>
    </div>







<footer style="background-color: #17181E; margin-top: 65px;" class="p-3">
  <div class="container mt-3">
    <div class="row p-3">
      <div class="col-md-3">
        <h6 style="color: #fff;">Web Tech <br> Company</h6>
      </div>
      <div class="col-md-6">
        
      </div>
      <div class="col-md-3">
        
        <div class="float-end">
          <button class="btn"><i class="bi bi-facebook" style="color: #fff;"></i></button>
        <button class="btn"><i class="bi bi-instagram" style="color: #fff;"></i></button>
        </div>

      </div>
    </div>

<hr>


<p style="color: #fff; text-align: center; font-weight: 400; font-size: 12px;">2021 &copy; Web Tech Comapny - All Right Reserved</p>


  </div>
</footer>







<script type="text/javascript">
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})
</script>
   
   <script src="path-to-the-file/splide.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>
  </body>
</html>